#pragma once
#define MAX 100
#define MESES 12
class Comp
{
	private:
		float ventas[MAX][MESES];
		int s;
public:
	Comp();
	void set_s(int _s);
	int get_s();
	void cargar();
	float totalventas();
	void menormes();
	void menorsuc();
	void ventasxsuc();


};


// PracticoCompania.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
using namespace std;
#include "Comp.h"
int main()
{
    int s;
    Comp c;
    cout << "Suc: ";
    cin >> s;
    c.set_s(s);
    c.cargar();
    c.menormes();
    c.menorsuc();
    return 0;

}


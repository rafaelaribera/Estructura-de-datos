#include "Comp.h"
using namespace std;
#include <iostream>
Comp::Comp() {

}
void Comp::set_s(int _s) {
	s = _s;
}
int Comp::get_s() {
	return s;
}
void Comp::cargar() {
	for (int i = 0; i < s; i++)
	{
		cout << "Respecto a la sucursal " << i + 1 << " " << endl;
		for (int j = 0; j < MESES; j++) {
			cout << "Ingrese la venta del mes " << j + 1 << ": ";
			cin >> ventas[i][j];
		}


	}
}
float Comp::totalventas() {
	float total = 0;
	for (int i = 0; i < s; i++)
	{
		for (int j = 0; j < MESES; j++) {
			total += ventas[i][j];
		}
	}
	return total;
}

void Comp::menormes() {
	float v[MAX];
	for (int i = 0; i < s; i++)
	{
		for (int j = 0; j < MESES; j++) {
			v[j] += ventas[i][j];

		}
	}
	int menormes = 0;
	float menorventa = v[0];
	for (int i = 0; i < MESES; i++) {
		if (v[i] < menorventa)
		{
			menormes = i;
			menorventa = v[i];
		}
	}
	cout << "El mes menos vendido es el numero: " << menormes + 1 << endl;

}
void Comp::menorsuc() {
	float v[MAX];
	for (int i = 0; i < s; i++) {
		for (int j = 0; i < MESES; j++) {
			v[i] = ventas[i][j];
		}
	}
	float mayorventas = v[0];
	int mayor = 0;
	for (int i = 0; i < s; i++)
	{
		if (v[i] > mayorventas)
		{	mayor = i;
		 mayorventas = v[i];
	}
		cout << "La suc con mas ventas es la " << mayor + 1;


}
void ventasxsuc();

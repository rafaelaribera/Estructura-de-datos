#include "Cola.h"
#include <iostream>
using namespace std;
Cola::Cola() {
	inicio = final = 0;
}

void Cola::push(int valor) {
	if (inicio == final)
		cout << "La cola esta vacia" << endl;
	if (final == MAX)
		cout << "La cola esta llena" << endl;
	else {
		info[final] = valor;
		final++;
	}

}
void Cola::pop() {
	if (inicio == final)
		cout << "La cola esta vacia" << endl;
	if (final == MAX)
		cout << "La cola esta llena" << endl;
	else {

	}
}
void Cola::mostrar() {
	if (inicio == final)
		cout << "La cola esta vacia" << endl;
	if (final == MAX)
		cout << "La cola esta llena" << endl;
	else {

	}
}
int Cola::size() {
	if (final >= inicio)
		return final - inicio;
	else
		return MAX - inicio + final;
}


// ColaEstaticaCod.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//
#include "Cola.h"
#include <iostream>
using namespace std;
int main()
{
    Cola l;
    int opcion, dato;
    do {
        
        cout << "MENU COLA ESTATICA" << endl;
        cout << "[1]Push" << endl;
        cout << "[2]Pop" << endl;
        cout << "[3]Mostrar" << endl;
        cout << "[4]Size" << endl;
        cout << "[0]Salir" << endl;
        cout << "\nIngresa tu opcion: ";
        cin >> opcion;
        switch (opcion) {
        case 1:
            cout << "Ingrese el dato a encolar: ";
            cin >> dato;
            l.push(dato);
            break;
        case 2:
            l.pop();
            break;
        case 3:
            l.mostrar();
            break;
        case 4:
            l.size();
            break;
        case 0:
            return 0;
            break;
        default:
            cout << "Por favor ingresa una opcion correcta.\n";
            break;
        }
    } while (opcion != 0);
    return 0;

}

// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln

#include <iostream>
#include "Cola.h"
#include "Dato.h"
using namespace std;

int main() {
    int opcion;
    Dato datito;
    Cola colita;
    do {
        cout << "Menu:" << endl;
        cout << "1. Push" << endl;
        cout << "2. Pop" << endl;
        cout << "3. Empty" << endl;
        cout << "4. Mostrar" << endl;
        cout << "0. Salir" << endl;
        cout << "Ingrese su opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            cout << "Ingrese el nombre:";
            cin >> datito.Nombre;
            cout << "Ingrese la carrera: ";
            cin >> datito.Carrera;
            cout << "Ingrese el codigo: ";
            cin >> datito.Codigo;
            colita.Push(datito);
            break;
        case 2:
            colita.Pop();
            cout << "Ha sacado el elemento mas antiguo" << endl;
            break;
        case 3:
            if (colita.isempty())
                cout << "La cola esta vacia" << endl;
            else
                cout << "La cola no esta vacia" << endl;

            break;
        case 4: {
            colita.Show();
        } break;
        case 0:
            cout << "Saliendo" << endl;
            break;
        default:
            cout << "Opci�n inv�lida." << endl;
        }
    } while (opcion != 0);

    return 0;
}
